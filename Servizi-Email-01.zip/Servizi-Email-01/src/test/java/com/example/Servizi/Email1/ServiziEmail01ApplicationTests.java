package com.example.Servizi.Email1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiziEmail01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
